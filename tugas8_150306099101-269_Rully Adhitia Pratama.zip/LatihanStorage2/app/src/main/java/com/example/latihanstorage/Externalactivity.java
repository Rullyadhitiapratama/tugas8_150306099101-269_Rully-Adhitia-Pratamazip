package com.example.latihanstorage;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class Externalactivity extends AppCompatActivity implements View.OnClickListener {
    Button kembali;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activty_external);

        kembali = findViewById(R.id.btnkembali1);
        kembali.setOnClickListener(this);
    }
    @Override
    public void onClick(View view){
        switch (view.getId()) {
            case R.id.btnkembali1:
                Intent external = new Intent(Externalactivity.this, MainActivity.class);
                startActivity(external);
                break;
        }
    }
}
