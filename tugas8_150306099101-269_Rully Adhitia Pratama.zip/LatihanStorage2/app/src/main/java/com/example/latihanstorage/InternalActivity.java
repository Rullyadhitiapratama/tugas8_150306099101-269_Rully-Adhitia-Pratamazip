package com.example.latihanstorage;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class InternalActivity extends AppCompatActivity implements View.OnClickListener {
    Button kembali;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_internal);

        kembali = findViewById(R.id.btnkembali2);
        kembali.setOnClickListener(this);
    }
    @Override
    public void onClick(View view){
        switch (view.getId()) {
            case R.id.btnkembali2:
                Intent internal = new Intent(InternalActivity.this, MainActivity.class);
                startActivity(internal);
                break;
        }
    }
}